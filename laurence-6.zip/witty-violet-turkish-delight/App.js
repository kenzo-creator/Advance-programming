import React,{Component} from 'react';
import {View,Text, Image, ScrollView, StyleSheet} from 'react-native';
export default class App extends Component{
  render(){
    return(
      <ScrollView>
      <View style = {styles.container}>
      <Image 
      source={{uri:'https://scontent.fmnl30-2.fna.fbcdn.net/v/t39.30808-6/426606255_7150732435021075_3194306654259611884_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=6ee11a&_nc_eui2=AeEZVJeAkW7VDvlNHXPfch-xfGsYjrDuUbF8axiOsO5RsXxrPniw7txlNzQ7k_4u2-My6hzenHuiEDq_s8WIq5sn&_nc_ohc=aRU4lZBZHLMQ7kNvgFipz0X&_nc_ht=scontent.fmnl30-2.fna&oh=00_AYDVhfHX4yisUsSiDfBlHJUnV-oidT6kT7skqKUgyRboHQ&oe=66D44531'}}
      style ={{width:200, height:200}}
      />
      <Text style={styles.text}>Laurence Parcon</Text>
      <Text style={styles.text}>BSIT</Text>
      <Text style={styles.text}>Medyo nag aaral ng mabuti</Text>
      </View>
      <View style={styles.container}>
      <Image
    source={{uri:''}}
      style={{width:200, height:200}}
      />
      <Text style={styles.text}></Text>
      </View>
      </ScrollView>
    );
  }
}
const styles = StyleSheet.create({
  container:{
    flex:1,
    alignItems:'center',
    justifyContent:'center',
    marginVertical:20,
  },
  text:{
    fontSize:24,
    fontWeight:'bold',
    textAlign:'center',
    marginVertical:10,
  },
});