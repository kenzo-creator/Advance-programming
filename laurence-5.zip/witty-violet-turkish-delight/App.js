import React,{Component} from 'react';
import {View,Text, Image, ScrollView, StyleSheet} from 'react-native';
export default class App extends Component{
  render(){
    return(
      <ScrollView>
      <View style = {styles.container}>
      <Image 
      source={{uri:'https://th.bing.com/th/id/OIP.XvzSwx563uXmyu8tVdmIYAHaHY?rs=1&pid=ImgDetMain'}}
      style ={{width:200, height:200}}
      />
      <Text></Text>
      </View>
      <View style={styles.container}>
      <Image
    source={{uri:'https://i.pinimg.com/originals/74/7c/4f/747c4f29e2a113589636b1a8b10f9521.jpg'}}
      style={{width:200, height:200}}
      />
      <Text style={styles.text}>THE PROFESSIONAL</Text>
      </View>
      </ScrollView>
    );
  }
}
const styles = StyleSheet.create({
  container:{
    flex:1,
    alignItems:'center',
    justifyContent:'center',
    marginVertical:20,
  },
  text:{
    fontSize:24,
    fontWeight:'bold',
    textAlign:'center',
    marginVertical:10,
  },
});